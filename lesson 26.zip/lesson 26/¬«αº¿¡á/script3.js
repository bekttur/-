let div = $(".wrap");

let array = JSON.parse(localStorage.getItem("cardArray"));

let clear = document.querySelector("#clear");
clear.addEventListener('click', () => {
    localStorage.setItem("cardArray", JSON.stringify([]));
})

let sum = 0;
let checkout = document.querySelector("#checkout");
for(let i = 0; i < array.length; i++){
    console.log(array[i].price)
    sum += Number(array[i].price);
}

checkout.addEventListener('click', () => {
    alert(`Вы должны оплатить ${sum} тенге.`);
})

for(let i = 0; i < array.length; i++){
    div.append(`
        <div class="purchase">
            <h5>${array[i].name}</h5>
            <p>${array[i].price} KZT</p>
            <hr>
        </div>
    `)

    
    
}
