let phones = document.querySelectorAll(".phones");
let button = document.querySelector("#btn");

let news = $(".news");
let user1 =JSON.parse(localStorage.getItem("userArray"));


news.append(`
    <h2 class="welcome">Добро пожаловать, ${user1[0].name}!</h2>
`)

for (let i = 0; i < phones.length; i++) {
    phones[i].addEventListener('click', (event) => {
        let eventElements = event.currentTarget;
        let name = eventElements.children[1].children[0].innerHTML;
        let price = eventElements.children[1].children[1].innerHTML;
        let site = eventElements.children[1].children[2].innerHTML;

        let item = {
            name: name,
            price: price,
            site: site,
        }

        console.log(localStorage.getItem("cardArray"));

        let array = JSON.parse(localStorage.getItem("cardArray"));
        if (array === null) {
            array = [];
        }

        array.push(item);
        localStorage.setItem("cardArray", JSON.stringify(array));
        console.log(array);
    })


    button.addEventListener('click', () => {
        location.href = "../корзина/index3.html"
    })
}





let tovar = $(".tovar");


let products = [
    {
        number: 13,
        memory: "512GB",
        color: "Pink",
        site: "Sulpak",
        price: 679990,
        img: "https://enter.online/images/detailed/172/apple_iphone_13_mini_pink_1_1631692747597.png"
    },
    {
        number: 12,
        memory: "64GB",
        color: "Золото",
        site: "OZON.ru",
        price: 429990,
        img: "https://magadan.shop.megafon.ru/images/goods/1359/135972_p_20.png"
    },
    {
        number: 12,
        memory: "256GB",
        color: "Blue",
        site: "Technodom",
        price: 509990,
        img: "https://htstatic.imgsmail.ru/pic_image/5ba8100818c85192744ffff07175316a/450/450/1909782/"
    },
    {
        number: 13,
        memory: "1024GB",
        color: "White",
        site: "Sulpak",
        price: 629990,
        img: "https://enter.online/images/detailed/172/apple_iphone_13_pro_silver_1_1631697473315.png"
    },


    {
        number: 5,
        memory: "64GB",
        color: "White",
        site: "Sulpak",
        price: 79990,
        img: "https://static.beeline.ru/shop/media/goods/334x434/0c29f75a-1d1b-4a4b-a9f0-33eff9f5116c.png"
    },
    {
        number: 6,
        memory: "128GB",
        color: "Black",
        site: "OZON.ru",
        price: 129990,
        img: "https://mobileoutlet.co.nz/wp-content/uploads/2021/01/iphone6-gray.png"
    },
    {
        number: 11,
        memory: "256GB",
        color: "Pink",
        site: "Technodom",
        price: 309990,
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone11-green-select-2019?wid=470&hei=556&fmt=png-alpha&.v=1566956144838"
    },
    {
        number: 11,
        memory: "512GB",
        color: "Red",
        site: "Sulpak",
        price: 329990,
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone11-red-select-2019?wid=470&hei=556&fmt=png-alpha&.v=1566956144763"
    },


    {
        number: 13,
        memory: "512GB",
        color: "Pink",
        site: "Sulpak",
        price: 579990,
        img: "https://enter.online/images/detailed/172/apple_iphone_13_mini_pink_1_1631692747597.png"
    },
    {
        number: 12,
        memory: "256GB",
        color: "Blue",
        site: "Technodom",
        price: 509990,
        img: "https://htstatic.imgsmail.ru/pic_image/5ba8100818c85192744ffff07175316a/450/450/1909782/"
    },
    {
        number: 13,
        memory: "1024GB",
        color: "White",
        site: "Sulpak",
        price: 629990,
        img: "https://enter.online/images/detailed/172/apple_iphone_13_pro_silver_1_1631697473315.png"
    },
    {
        number: 12,
        memory: "64GB",
        color: "Золото",
        site: "OZON.ru",
        price: 429990,
        img: "https://magadan.shop.megafon.ru/images/goods/1359/135972_p_20.png"
    },


    {
        number: 6,
        memory: "128GB",
        color: "Black",
        site: "OZON.ru",
        price: 129990,
        img: "https://mobileoutlet.co.nz/wp-content/uploads/2021/01/iphone6-gray.png"
    },
    {
        number: 11,
        memory: "256GB",
        color: "Green",
        site: "Technodom",
        price: 309990,
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone11-green-select-2019?wid=470&hei=556&fmt=png-alpha&.v=1566956144838"
    },
    {
        number: 11,
        memory: "128GB",
        color: "Red",
        site: "Sulpak",
        price: 329990,
        img: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone11-red-select-2019?wid=470&hei=556&fmt=png-alpha&.v=1566956144763"
    },
    {
        number: 5,
        memory: "64GB",
        color: "White",
        site: "Sulpak",
        price: 79990,
        img: "https://static.beeline.ru/shop/media/goods/334x434/0c29f75a-1d1b-4a4b-a9f0-33eff9f5116c.png"
    },


    {
        number: 13,
        memory: "512GB",
        color: "Pink",
        site: "Sulpak",
        price: 679990,
        img: "https://enter.online/images/detailed/172/apple_iphone_13_mini_pink_1_1631692747597.png"
    },
    {
        number: 12,
        memory: "64GB",
        color: "Золото",
        site: "OZON.ru",
        price: 429990,
        img: "https://magadan.shop.megafon.ru/images/goods/1359/135972_p_20.png"
    },
    {
        number: 12,
        memory: "256GB",
        color: "Blue",
        site: "Technodom",
        price: 509990,
        img: "https://htstatic.imgsmail.ru/pic_image/5ba8100818c85192744ffff07175316a/450/450/1909782/"
    },
    {
        number: 13,
        memory: "1024GB",
        color: "White",
        site: "Sulpak",
        price: 629990,
        img: "https://enter.online/images/detailed/172/apple_iphone_13_pro_silver_1_1631697473315.png"
    },

]

function showProducts(categoryName) {
    tovar.empty();

    console.log(categoryName)

    products.map(item => {
        if (item.number == Number(categoryName) || categoryName === null) {
            tovar.append(`
        <div class="second">
        <div class="phones">
            <div class="images">
                <img class="phoneimg" src=${item.img}>
            </div>
            <div class="info">
                <h3 class="information">Смартфон IPhone ${item.number} ${item.memory} ${item.color}</h3>
                <h3>${item.price} тг</h3>
            </div>
        </div>
        </div>
        `)
        }

    })
}

let selectedCategory = null;

let categorySelect = document.querySelector("#category_select");
categorySelect.addEventListener('change', () => {
    selectedCategory = categorySelect.value;
    showProducts(selectedCategory);
})

